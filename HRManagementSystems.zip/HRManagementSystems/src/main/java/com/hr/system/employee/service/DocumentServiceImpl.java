package com.hr.system.employee.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hr.system.company.bean.ProjectAccessBean;
import com.hr.system.company.repository.ProjectRepository;
import com.hr.system.employee.bean.AccountDetailsAccessBean;
import com.hr.system.employee.bean.EmployeeAccessBean;
import com.hr.system.employee.repository.AccountDetailsRepository;
import com.hr.system.employee.repository.EmpWorkRelationRepository;
import com.hr.system.employee.repository.EmployeeRepository;

@Service
public class DocumentServiceImpl implements DocumentService {

	


}
