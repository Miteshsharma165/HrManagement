/*
 * package com.hr.system.company.repository;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository;
 * 
 * import com.hr.system.company.bean.EmpWorkRelationAccessBean; import
 * com.hr.system.employee.bean.EmployeeAccessBean;
 * 
 * 
 * public interface EmpWorkRelationRepository extends
 * JpaRepository<EmpWorkRelationAccessBean, Long>{
 * 
 * String findDesignationByEmployeeAccessBean(EmployeeAccessBean
 * employeeAccessBean);
 * 
 * }
 */