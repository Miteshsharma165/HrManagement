package com.hr.system.employee.service;

import java.util.Map;

public interface DocumentService {


}
