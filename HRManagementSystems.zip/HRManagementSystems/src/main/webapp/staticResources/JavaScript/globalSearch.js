$(document).ready(function() {
		
		// Global Filter Functionality.......
		
	/*	var $rows = $('#salaryRevisionTable tr');
		$('#search').keyup(function() {
		    var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();
		    
		    $rows.show().filter(function() {
		        var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
		        return !~text.indexOf(val);
		    }).hide();
		});

		$('#salaryRevisionTable input').each( function () {
	        var title = $(this).text();
	    } );
		
		var table = $('#salaryRevisionTable').DataTable({
	        initComplete: function () {
	            // Apply the search
	            this.api().columns().every( function () {
	                var that = this;
	 
	                $( 'input', this.thead ).on( 'keyup change clear', function () {
	                    if ( that.search() !== this.value ) {
	                        that
	                            .search( this.value )
	                            .draw();
	                    }
	                } );
	            } );
	        }
	    });*/
	} );



