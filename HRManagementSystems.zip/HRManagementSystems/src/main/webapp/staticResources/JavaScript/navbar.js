/*<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>

$(document).ready(function() {
	$("#on_company").hide();
	$("#on_profile").hide();
    $("#on_attendance").hide();
    $("#on_directory").hide();
    $("#on_leave").hide();
    $("#on_payroll").hide();
    $("#on_setting").hide();

	$("#home").click(function(){
	    $("#on_home").show();
	    $("#on_company").hide();
	    $("#on_profile").hide();
	    $("#on_attendance").hide();
	    $("#on_directory").hide();
	    $("#on_leave").hide();
	    $("#on_payroll").hide();
	    $("#on_setting").hide();
	});

	$("#company").click(function(){
		 $("#on_home").hide();
		 $("#on_company").show();
		    $("#on_profile").hide();
		    $("#on_attendance").hide();
		    $("#on_directory").hide();
		    $("#on_leave").hide();
		    $("#on_payroll").hide();
		    $("#on_setting").hide();
	});

	$("#profile").click(function(){
		 $("#on_home").hide();
		    $("#on_company").hide();
		    $("#on_profile").show();
		    $("#on_attendance").hide();
		    $("#on_directory").hide();
		    $("#on_leave").hide();
		    $("#on_payroll").hide();
		    $("#on_setting").hide();
	});

	$("#attendance").click(function(){
		 $("#on_home").hide();
		    $("#on_company").hide();
		    $("#on_profile").hide();
		    $("#on_attendance").show();
		    $("#on_directory").hide();
		    $("#on_leave").hide();
		    $("#on_payroll").hide();
		    $("#on_setting").hide();
	});

	$("#directory").click(function(){
		 $("#on_home").hide();
		    $("#on_company").hide();
		    $("#on_profile").hide();
		    $("#on_attendance").hide();
		    $("#on_directory").show();
		    $("#on_leave").hide();
		    $("#on_payroll").hide();
		    $("#on_setting").hide();
	});

	$("#leave").click(function(){
		 $("#on_home").hide();
		    $("#on_company").hide();
		    $("#on_profile").hide();
		    $("#on_attendance").hide();
		    $("#on_directory").hide();
		    $("#on_leave").show();
		    $("#on_payroll").hide();
		    $("#on_setting").hide();
	});

	$("#payroll").click(function(){
		 $("#on_home").hide();
		    $("#on_company").hide();
		    $("#on_profile").hide();
		    $("#on_attendance").hide();
		    $("#on_directory").hide();
		    $("#on_leave").hide();
		    $("#on_payroll").show();
		    $("#on_setting").hide();
	});
	
	$("#setting").click(function(){
		 $("#on_home").hide();
		    $("#on_company").hide();
		    $("#on_profile").hide();
		    $("#on_attendance").hide();
		    $("#on_directory").hide();
		    $("#on_leave").hide();
		    $("#on_payroll").hide();
		    $("#on_setting").show();
	});
});*/